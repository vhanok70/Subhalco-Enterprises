import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowUpRight, ArrowRight, Menu, X, ShieldCheck, Globe2, Boxes,
  Factory, Truck, Layers3, Zap, Building2, Mail, Phone, MapPin,
  CheckCircle2, ChevronDown
} from "lucide-react";

const products = [
  { no:"01", name:"Aluminium Ingots", grade:"A7 · ADC12", desc:"Primary and secondary aluminium grades for foundry, casting and industrial manufacturing requirements.", image:"https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=1000&q=85" },
  { no:"02", name:"Aluminium Billets", grade:"6063 · By specification", desc:"Aluminium billet sourcing for extrusion, fabrication and downstream industrial applications.", image:"https://images.unsplash.com/photo-1567789884554-0b844b597180?auto=format&fit=crop&w=1000&q=85" },
  { no:"03", name:"Copper Products", grade:"Cathodes · Millberry", desc:"Copper material sourcing for electrical, industrial and metal processing requirements.", image:"https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=85" },
  { no:"04", name:"Non-Ferrous Metals", grade:"Scrap · Other grades", desc:"Requirement-led sourcing support for selected non-ferrous metal categories.", image:"https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=1000&q=85" }
];

const industries = [
  ["Manufacturing", Factory], ["Automotive", Truck], ["Electrical & Power", Zap],
  ["Engineering", Layers3], ["Metal Processing", Boxes], ["Infrastructure", Building2]
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: { opacity: 1, y: 0, transition: { duration: .65, ease: [0.22, 1, 0.36, 1] } }
};

function Reveal({ children, className="" }) {
  return <motion.div className={className} variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once:true, amount:.14 }}>{children}</motion.div>;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [form, setForm] = useState({ name:"", company:"", email:"", product:"", quantity:"", message:"" });

  const nav = [["About","about"],["Products","products"],["Industries","industries"],["Our Approach","approach"]];
  const update = (e) => setForm({ ...form, [e.target.name]:e.target.value });
  const submit = (e) => {
    e.preventDefault();
    const subject = encodeURIComponent("Business enquiry — " + (form.product || "Subhalco Enterprises"));
    const body = encodeURIComponent(
      `Name: ${form.name}\nCompany: ${form.company}\nEmail: ${form.email}\nProduct: ${form.product}\nQuantity: ${form.quantity}\n\n${form.message}`
    );
    // Replace this email with your official company email before publishing.
    window.location.href = `mailto:YOUR-EMAIL@example.com?subject=${subject}&body=${body}`;
  };

  return (
    <div className="site-shell">
      <div className="topline"><span>INDUSTRIAL METALS & COMMODITY TRADING</span><span className="topline-right"><Globe2 size={13}/> INDIA <i/> BUSINESS ENQUIRIES WELCOME</span></div>
      <header className="header">
        <a className="brand" href="#home" aria-label="Subhalco Enterprises home">
          <span className="brand-mark"><span/></span>
          <span className="brand-copy"><b>SUBHALCO</b><small>ENTERPRISES</small></span>
        </a>
        <nav className={menuOpen ? "nav nav-open" : "nav"}>
          {nav.map(([label,id]) => <a key={id} href={`#${id}`} onClick={()=>setMenuOpen(false)}>{label}</a>)}
          <a className="mobile-contact" href="#contact" onClick={()=>setMenuOpen(false)}>Contact us <ArrowUpRight size={16}/></a>
        </nav>
        <a className="header-cta" href="#contact">LET'S TALK <ArrowUpRight size={16}/></a>
        <button className="menu-toggle" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X/> : <Menu/>}</button>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-image"/>
          <div className="hero-shade"/>
          <div className="hero-grid"/>
          <div className="hero-content">
            <motion.div className="eyebrow light" initial={{opacity:0,x:-18}} animate={{opacity:1,x:0}} transition={{duration:.7}}>
              <span className="eyebrow-line"/> BUILT AROUND YOUR MATERIAL REQUIREMENTS
            </motion.div>
            <motion.h1 initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} transition={{duration:.8,delay:.12}}>
              The right metals.<br/><em>The right connections.</em>
            </motion.h1>
            <motion.p initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.7,delay:.25}}>
              Sourcing and supply coordination for aluminium, copper and non-ferrous metal requirements across industry.
            </motion.p>
            <motion.div className="hero-actions" initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.7,delay:.38}}>
              <a className="btn btn-accent" href="#products">EXPLORE OUR PRODUCTS <ArrowUpRight size={17}/></a>
              <a className="text-link light-link" href="#about">DISCOVER SUBHALCO <ArrowRight size={17}/></a>
            </motion.div>
          </div>
          <div className="hero-bottom"><span>01 / INDUSTRIAL METAL SOLUTIONS</span><span>SCROLL TO EXPLORE <span className="scroll-line"/></span></div>
          <div className="hero-index">SE</div>
        </section>

        <section className="intro section-pad" id="about">
          <Reveal><div className="eyebrow"><span className="eyebrow-line"/> WHO WE ARE</div></Reveal>
          <div className="intro-grid">
            <Reveal><h2>Trade built on<br/><em>clarity and trust.</em></h2></Reveal>
            <Reveal><div className="intro-copy"><p className="lead">Subhalco Enterprises is an India-based industrial metals trading business focused on connecting buyers with relevant material sourcing opportunities.</p><p>We work around product specifications, grade, quantity and delivery requirements to coordinate practical supply conversations between businesses. Our approach is straightforward: understand the requirement, communicate clearly and support the process from enquiry to execution.</p><a className="under-link" href="#approach">HOW WE WORK <ArrowUpRight size={16}/></a></div></Reveal>
          </div>
          <div className="intro-rule"><span>01</span><span>RELIABLE SOURCING</span><span>RESPONSIVE COMMUNICATION</span><span>BUSINESS-TO-BUSINESS</span></div>
        </section>

        <section className="products section-pad" id="products">
          <div className="section-heading">
            <Reveal><div className="eyebrow light"><span className="eyebrow-line"/> OUR PORTFOLIO</div><h2>Materials that<br/><em>move industry.</em></h2></Reveal>
            <Reveal><p className="section-aside">Explore our key product categories. Availability, grade, specification and quantity are confirmed against each individual enquiry.</p></Reveal>
          </div>
          <div className="product-grid">
            {products.map((p,i)=><Reveal key={p.no}><article className="product-card">
              <div className="product-photo"><img src={p.image} alt={p.name}/><span className="product-number">{p.no}</span><a href="#contact" className="round-arrow" aria-label={`Enquire about ${p.name}`}><ArrowUpRight/></a></div>
              <div className="product-info"><span>{p.grade}</span><h3>{p.name}</h3><p>{p.desc}</p><a href="#contact" className="product-link">ENQUIRE ABOUT THIS <ArrowRight size={15}/></a></div>
            </article></Reveal>)}
          </div>
          <div className="portfolio-note"><span className="note-dot"/> Looking for a specific grade or material? <a href="#contact">Share your requirement <ArrowUpRight size={14}/></a></div>
        </section>

        <section className="industries section-pad" id="industries">
          <div className="industries-head"><Reveal><div className="eyebrow"><span className="eyebrow-line"/> INDUSTRIES WE SUPPORT</div><h2>Connected to the<br/><em>industries of tomorrow.</em></h2></Reveal><Reveal><p>Metal requirements differ from one application to another. We engage with businesses across industrial sectors to understand their material needs and coordinate relevant supply options.</p></Reveal></div>
          <div className="industry-grid">{industries.map(([name,Icon],i)=><Reveal key={name}><div className="industry-item"><span className="industry-no">0{i+1}</span><Icon size={25} strokeWidth={1.5}/><h3>{name}</h3><ArrowUpRight className="industry-arrow" size={18}/></div></Reveal>)}</div>
        </section>

        <section className="approach" id="approach">
          <div className="approach-visual"><img src="https://images.unsplash.com/photo-1567789884554-0b844b597180?auto=format&fit=crop&w=1400&q=85" alt="Industrial metal production"/></div>
          <div className="approach-content section-pad">
            <Reveal><div className="eyebrow light"><span className="eyebrow-line"/> OUR APPROACH</div><h2>A clear process.<br/><em>A stronger partnership.</em></h2><p className="approach-desc">Every successful supply conversation starts with understanding the requirement. Our process is designed to keep communication direct and expectations clear.</p></Reveal>
            <div className="steps">
              {[["01","Understand","We review your material, grade, specification, quantity and destination."],["02","Coordinate","We work to identify relevant sourcing and supply options for the requirement."],["03","Align","Commercial terms, logistics responsibilities and documentation are discussed."],["04","Follow through","We coordinate communication through the agreed transaction process."]].map(([n,t,d])=><Reveal key={n}><div className="step"><span>{n}</span><div><h3>{t}</h3><p>{d}</p></div><ArrowUpRight size={17}/></div></Reveal>)}
            </div>
          </div>
        </section>

        <section className="why section-pad">
          <Reveal><div className="eyebrow"><span className="eyebrow-line"/> THE SUBHALCO APPROACH</div><h2>Business is better<br/>when the details <em>are clear.</em></h2></Reveal>
          <div className="why-grid">
            {[[ShieldCheck,"Requirement-led","We start with the exact grade, specification, quantity and delivery needs."],[Globe2,"Sourcing perspective","We engage with supply opportunities relevant to the product and requirement."],[Boxes,"Product focus","A considered portfolio across aluminium, copper and selected non-ferrous metals."],[CheckCircle2,"Clear communication","Straightforward discussions around availability, commercial terms and next steps."]].map(([Icon,t,d])=><Reveal key={t}><div className="why-card"><Icon size={27} strokeWidth={1.5}/><h3>{t}</h3><p>{d}</p></div></Reveal>)}
          </div>
        </section>

        <section className="cta-band"><div><span>HAVE A MATERIAL REQUIREMENT?</span><h2>Let's make the<br/><em>next connection.</em></h2></div><a className="btn btn-accent" href="#contact">START AN ENQUIRY <ArrowUpRight size={17}/></a><div className="cta-orbit"/></section>

        <section className="contact section-pad" id="contact">
          <div className="contact-left"><Reveal><div className="eyebrow light"><span className="eyebrow-line"/> GET IN TOUCH</div><h2>Tell us what<br/>you <em>need.</em></h2><p>Share your product specifications and requirement. Our team can review the details and get back to you.</p>
            <div className="contact-detail"><Mail size={18}/><div><small>EMAIL</small><span>Add your official email</span></div></div>
            <div className="contact-detail"><Phone size={18}/><div><small>PHONE / WHATSAPP</small><span>Add your business number</span></div></div>
            <div className="contact-detail"><MapPin size={18}/><div><small>BUSINESS LOCATION</small><span>India</span></div></div>
          </Reveal></div>
          <Reveal><form className="contact-form" onSubmit={submit}>
            <div className="form-title"><span>BUSINESS ENQUIRY</span><span>01 — 06</span></div>
            <div className="form-row"><label>Your name<input name="name" value={form.name} onChange={update} placeholder="Full name" required/></label><label>Company<input name="company" value={form.company} onChange={update} placeholder="Company name"/></label></div>
            <label>Business email<input type="email" name="email" value={form.email} onChange={update} placeholder="name@company.com" required/></label>
            <div className="form-row"><label>Product requirement<select name="product" value={form.product} onChange={update} required><option value="">Select product</option>{products.map(p=><option key={p.no}>{p.name}</option>)}<option>Other / Custom requirement</option></select></label><label>Quantity<input name="quantity" value={form.quantity} onChange={update} placeholder="e.g. 25 MT"/></label></div>
            <label>Tell us about your requirement<textarea name="message" value={form.message} onChange={update} rows="3" placeholder="Grade, specification, delivery location and any other details..."/></label>
            <button className="btn btn-accent submit-btn" type="submit">SEND ENQUIRY <ArrowUpRight size={17}/></button>
            <p className="form-disclaimer">Please replace the placeholder company email in the code before publishing.</p>
          </form></Reveal>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-main"><a className="brand footer-brand" href="#home"><span className="brand-mark"><span/></span><span className="brand-copy"><b>SUBHALCO</b><small>ENTERPRISES</small></span></a><p>Industrial metals sourcing, trading<br/>and supply coordination.</p><a className="back-top" href="#home">BACK TO TOP <ArrowUpRight size={16}/></a></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} SUBHALCO ENTERPRISES. ALL RIGHTS RESERVED.</span><span>INDUSTRIAL METALS & COMMODITY TRADING</span></div>
      </footer>
    </div>
  );
}

export default App;